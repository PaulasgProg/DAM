package com.example.roombd.basico.screen
//objeto que pueda ver toda la app pero sin acceso al ID
data class User(//es el que se usará en UI de la App
    val nombre:String
)
