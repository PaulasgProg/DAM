package dev.dacape.example.kotlin.crudroomjetpackcompose.core

data class TextFieldState(
    val text: String = ""
)