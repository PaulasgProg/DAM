package vista;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import dataBase.Controlador;

public class VentanaCrearUsuario extends JFrame {
	private JPanel panel;
	private JLabel lbl_dni,lbl_nombre,lbl_apellido,lbl_valores;
	private JTextField txt_dni,txt_nombre,txt_apellido;
	private JButton btn_CrearUsuario,btn_Cancelar;

	public VentanaCrearUsuario(Controlador controlador) {
	
		setTitle("APP BIBLIOTECA");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(550, 250, 350, 300);
		panel=new JPanel();
		panel.setBorder(new EmptyBorder(5,5,5,5));
		
		panel.setLayout(null);
		setContentPane(panel);
		
		lbl_valores=new JLabel("DATOS USUARIO");
		lbl_valores.setBounds(120, 10, 131, 23);
		panel.add(lbl_valores);
		
		lbl_nombre=new JLabel("Introduce tu nombre");
		lbl_nombre.setBounds(30, 40, 131, 23);
		panel.add(lbl_nombre);
		
		txt_nombre=new JTextField();
		txt_nombre.setBounds(180, 40, 120, 23);
		txt_nombre.setColumns(12);
		panel.add(txt_nombre);
		
		lbl_apellido=new JLabel("Introduce tu apellido");
		lbl_apellido.setBounds(30, 80, 131, 23);
		panel.add(lbl_apellido);
		
		txt_apellido=new JTextField();
		txt_apellido.setBounds(180, 80, 120, 23);
		txt_apellido.setColumns(12);
		panel.add(txt_apellido);
		
		lbl_dni=new JLabel("Introduce tu DNI");
		lbl_dni.setBounds(30, 120, 131, 23);
		panel.add(lbl_dni);
		
		txt_dni=new JTextField();
		txt_dni.setBounds(180, 120, 120, 23);
		txt_dni.setColumns(12);
		panel.add(txt_dni);
		
		btn_CrearUsuario=new JButton("Crear usuario");
		btn_CrearUsuario.setBounds(30, 190, 120, 20);
		btn_CrearUsuario.addActionListener(controlador);
		btn_CrearUsuario.setActionCommand("Nuevo Usuario");
		panel.add(btn_CrearUsuario);
		
		btn_Cancelar=new JButton("Cancelar");
		btn_Cancelar.setBounds(180, 190, 120, 20);
		btn_Cancelar.addActionListener(controlador);
		btn_Cancelar.setActionCommand("Cancelar crear");
		panel.add(btn_Cancelar);
		
	}
	public String[] getValues() {
		
		String[] values= {txt_nombre.getText(),txt_apellido.getText(),txt_dni.getText()};
		return values;
	}
	

}
