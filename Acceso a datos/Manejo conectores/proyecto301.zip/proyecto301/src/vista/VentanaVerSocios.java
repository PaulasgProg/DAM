package vista;

import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import dataBase.Controlador;
import libreria.Cliente;

public class VentanaVerSocios extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JScrollPane scrollPane;
	private Controlador controlador;
	
	public void setControlador(Controlador controlador) {
		this.controlador=controlador;
	}
	

	public void actualizarTabla(ArrayList<Cliente> array) {
		ArrayList<Cliente> listaClientes=array;
		
		String[] headers={ "DNI", "Nombre", "Apellidos" };
		DefaultTableModel tablemodel=new DefaultTableModel(headers,0);
		
		for (Cliente cliente : listaClientes) {
			tablemodel.addRow(new Object[] {cliente.getDNI(),cliente.getName(),cliente.getSurname()});
		}
		table.setModel(tablemodel);
	
	}

	public VentanaVerSocios(Controlador controlador) {
		setTitle("APP BIBLIOTECA");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(550, 250, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setControlador(controlador);

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblSocios = new JLabel("LISTA SOCIOS");
		lblSocios.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblSocios.setBounds(158, 22, 135, 27);
		contentPane.add(lblSocios);

		scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 60, 392, 174);
		contentPane.add(scrollPane);

		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "DNI", "Nombre", "Apellidos" }));
	}
}
