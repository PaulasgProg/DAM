package vista;

import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import dataBase.Controlador;

public class VentanaLibrosAlquilados extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JScrollPane scrollPane;
	private Controlador controlador;

	public void setControlador(Controlador controlador) {
		this.controlador=controlador;
	}
	public void ActualizarTabla(ArrayList<Object> array) {
		ArrayList<Object> librosAlquilados=array;
		String[] headers={ "Codigo", "Titulo", "Socio", "Fecha" };
		DefaultTableModel tableModel=new DefaultTableModel(headers,0);
		
		for (Object object : librosAlquilados) {
			if( object instanceof Object[]) {
				Object[] arrayObj=(Object[]) object;
				tableModel.addRow(new Object[] {arrayObj[1],arrayObj[2],arrayObj[3],arrayObj[4]});
			}
			
		}
		table.setModel(tableModel);
	}
	public VentanaLibrosAlquilados(Controlador controlador) {
		setTitle("APP BIBLIOTECA");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(550, 250, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setControlador(controlador);

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblAlquilados = new JLabel("LIBROS ALQUILADOS");
		lblAlquilados.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblAlquilados.setBounds(128, 24, 192, 27);
		contentPane.add(lblAlquilados);

		scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 60, 392, 174);
		contentPane.add(scrollPane);

		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "Codigo", "Titulo", "Socio", "Fecha" }));
	}
}
