package vista;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import dataBase.Controlador;

public class VentanaEliminarSocio extends JFrame {
	JTextField txt_dni;

	public VentanaEliminarSocio(Controlador controlador) {
		setTitle("APP BIBLIOTECA");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(550, 250, 350, 300);
		JPanel panel = new JPanel();
		panel.setBorder(new EmptyBorder(5,5,5,5));
		
		panel.setLayout(null);
		setContentPane(panel);
		
		JLabel lbl_valores = new JLabel("DATOS USUARIO");
		lbl_valores.setBounds(120, 10, 131, 23);
		panel.add(lbl_valores);
		
		JLabel lbl_dni = new JLabel("Introduce el DNI del usuario a eliminiar:");
		lbl_dni.setBounds(70, 40, 250, 23);
		panel.add(lbl_dni);
		
		txt_dni = new JTextField();
		txt_dni.setBounds(120, 80, 120, 23);
		txt_dni.setColumns(12);
		panel.add(txt_dni);
		
		JButton btn_Cancelar = new JButton("Cancelar");
		btn_Cancelar.setBounds(180, 190, 120, 20);
		btn_Cancelar.addActionListener(controlador);
		btn_Cancelar.setActionCommand("Cancelar ELIMINAR");
		panel.add(btn_Cancelar);
		
		JButton btn_Eliminar = new JButton("Eliminar");
		btn_Eliminar.setBounds(50, 190, 120, 20);
		btn_Eliminar.addActionListener(controlador);
		btn_Eliminar.setActionCommand("Confirmar ELIMINAR");
		panel.add(btn_Eliminar);
	}
	
	public String getValue() {
		return txt_dni.getText();
	}
}
