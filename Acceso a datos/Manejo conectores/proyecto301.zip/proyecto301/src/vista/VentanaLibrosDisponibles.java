package vista;

import java.awt.Font;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import dataBase.Controlador;
import libreria.Libro;

public class VentanaLibrosDisponibles extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JScrollPane scrollPane;
	private Controlador controlador;
	
	public void setControlador(Controlador controlador) {
		this.controlador=controlador;
	}
	public void ActualizarTbla(ArrayList<Libro> array) {
		ArrayList<Libro> listaDisponibles=array;
		String [] headers= {"Codigo", "Titulo", "Autor"};
		DefaultTableModel tablemodel=new DefaultTableModel(headers,0);
		
		for (Libro libro : listaDisponibles) {
			tablemodel.addRow(new Object[] {libro.getCode(),libro.getTitle(),libro.getAutor()});
		}
		table.setModel(tablemodel);
	}


	public VentanaLibrosDisponibles(Controlador controlador) {
		setTitle("APP BIBLIOTECA");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(550, 250, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setControlador(controlador);

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblDisponibles = new JLabel("LIBROS DISPONIBLES");
		lblDisponibles.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblDisponibles.setBounds(128, 24, 192, 27);
		contentPane.add(lblDisponibles);

		scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 60, 392, 174);
		contentPane.add(scrollPane);

		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(new Object[][] {}, new String[] { "Codigo", "Titulo", "Autor" }));
	}

}
