package vista;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

import dataBase.Controlador;

public class VentanaPrincipal extends JFrame {

	private JPanel contentPane;
	private Controlador controlador;
	private JPanel noSocios,eliminarSocio;
	
	public void setControlador(Controlador controlador) {
		this.controlador=controlador;
	}

	public VentanaPrincipal(Controlador controlador) {
		setTitle("APP BIBLIOTECA");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(550, 250, 400, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setControlador(controlador);

		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton btnAlquilarLibro = new JButton("Alquilar libro");
		btnAlquilarLibro.setBounds(240, 30, 131, 23);
		btnAlquilarLibro.addActionListener(controlador);
		btnAlquilarLibro.setActionCommand("Alquilar");
		contentPane.add(btnAlquilarLibro);

		JButton btnDevolverLibro = new JButton("Devolver libro");
		btnDevolverLibro.setBounds(240, 71, 131, 23);
		btnDevolverLibro.addActionListener(controlador);
		btnDevolverLibro.setActionCommand("Devolver");
		contentPane.add(btnDevolverLibro);

		JButton btnLibrosDisponibles = new JButton("Ver libros disponibles");
		btnLibrosDisponibles.setBounds(21, 71, 160, 23);
		btnLibrosDisponibles.addActionListener(controlador);
		btnLibrosDisponibles.setActionCommand("Ver libros disponibles");
		contentPane.add(btnLibrosDisponibles);

		JButton btnVerSocios = new JButton("Ver socios");
		btnVerSocios.setBounds(35, 30, 131, 23);
		btnVerSocios.addActionListener(controlador);
		btnVerSocios.setActionCommand("Ver socios");
		contentPane.add(btnVerSocios);

		JButton btnLibrosAlquilados = new JButton("Ver libros alquilados");
	    btnLibrosAlquilados.setBounds(21, 110, 160, 23);
		btnLibrosAlquilados.addActionListener(controlador);
		btnLibrosAlquilados.setActionCommand("Libros alquilados");
		contentPane.add(btnLibrosAlquilados);

		JButton btnHistorico = new JButton("Ver histórico");
		btnHistorico.setBounds(240, 110, 131, 23);
		btnHistorico.addActionListener(controlador);
		btnHistorico.setActionCommand("Historico");
		contentPane.add(btnHistorico);
		
		noSocios=new JPanel();
		noSocios.setBorder(BorderFactory.createTitledBorder("CREAR USUARIO"));
		noSocios.setBounds(21, 170, 160, 70);
		
		JButton btnCrearUsuario=new JButton("Nuevo usuario");
		btnCrearUsuario.addActionListener(controlador);
		btnCrearUsuario.setActionCommand("Crear Usuario");
		noSocios.add(btnCrearUsuario);
		
		contentPane.add(noSocios);
		
		eliminarSocio=new JPanel();
		eliminarSocio.setBorder(BorderFactory.createTitledBorder("ELIMINAR USUARIO"));
		eliminarSocio.setBounds(220, 170, 160, 70);
		
		JButton btnEliminarUsuario=new JButton("Eliminar usuario");
		btnEliminarUsuario.addActionListener(controlador);
		btnEliminarUsuario.setActionCommand("Eliminar Usuario");
		eliminarSocio.add(btnEliminarUsuario);
		
		contentPane.add(eliminarSocio);
	}
}
