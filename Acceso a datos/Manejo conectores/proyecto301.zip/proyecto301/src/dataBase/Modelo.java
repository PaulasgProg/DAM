package dataBase;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.tools.SimpleJavaFileObject;

import libreria.*;
import java.time.LocalDate;

public class Modelo {
	private Connection conn;
	private String url="jdbc:mysql://localhost:3306/libreriapaula";
	private String user="root";
	private String psw="abc123.";
	
	
	Modelo(){
		openConnection();
	}
	public void openConnection() {
		try {
			this.conn=DriverManager.getConnection(url,user,psw);
			System.out.println("Conectado a BD ");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Error en la conexón a la BD ","Mensaje informativo",JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public void closeConnection() {
		try {
			this.conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public ArrayList<Cliente> verSocios() {
		ArrayList<Cliente> listaSocios=new ArrayList<Cliente>();
		
		String verSocios="SELECT * FROM socio";
		try {
			Statement st=conn.createStatement();
			ResultSet resul=st.executeQuery(verSocios);
			
			while(resul.next()) {
				listaSocios.add(new Cliente(resul.getInt(1),resul.getString(2),resul.getString(3),resul.getString(4)));
			}
			return listaSocios;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Error cogiendo la informacion de los socios","Mensaje informativo",JOptionPane.ERROR_MESSAGE);
			closeConnection();
			return listaSocios;
			
	
		}
		
	}
	public ArrayList<Libro> verLibrosDisponibles() {
		ArrayList<Libro> listaLibros=new ArrayList<Libro>();
		ArrayList<String> listaCode=new ArrayList<String>();
		int tamaño=0;
		
		String code="SELECT codigo FROM libro";

		String librosDisponibles="SELECT DISTINCT idLibro, codigo , titulo , autor from libro where codigo=? ";
		try {
			
			Statement st1=conn.createStatement();
			ResultSet resul1=st1.executeQuery(code);
			
			PreparedStatement ps=conn.prepareStatement(librosDisponibles);
			while (resul1.next()) {
				listaCode.add(resul1.getString(1));
				
			}
			
			for (int i = 0; i <listaCode.size(); i++) {
				if(!prestado(listaCode.get(i))){
					
					String codeLibro=listaCode.get(i);
					ps.setString(1, codeLibro);
					ResultSet resul=ps.executeQuery();
					while(resul.next()) {
						listaLibros.add(new Libro(resul.getInt(1),resul.getString(2),resul.getString(3),resul.getString(4)));
					}
					
				}
			}
							
			
			return listaLibros;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			closeConnection();
			JOptionPane.showMessageDialog(null, "Error recogiendo los libros disponibles","Mensaje informativo",JOptionPane.ERROR_MESSAGE);
			return listaLibros;
		}
		
	}
	public ArrayList<Object> verLibrosAlquilados() {
		ArrayList<Object> listaLibros=new ArrayList<Object>();
		
		String librosAlquilados="SELECT li.idLibro,li.codigo , li.titulo , so.nombre, pre.fecha from libro as li "
				+ "join prestamos as pre on li.idLibro=pre.idLibro join socio as so on so.idCliente=pre.idCliente"
				+ " where pre.prestado=1";
		try {
			Statement st=conn.createStatement();
			ResultSet resul=st.executeQuery(librosAlquilados);
			
			while(resul.next()) {
				listaLibros.add(new Object[] {resul.getInt(1),resul.getString(2),resul.getString(3),resul.getString(4),resul.getDate(5)});	
			}
			return listaLibros;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			closeConnection();
			JOptionPane.showMessageDialog(null, "Error recogiendo los libros alquilados","Mensaje informativo",JOptionPane.ERROR_MESSAGE);
			return listaLibros;
		}
		
	}
	public Boolean prestado(String codigo) {
		int idLibro=0;
		boolean prestado=false;
		String sql="SELECT idLibro from libro where codigo= ?";
		
		String sql1="SELECT  idLibro, MAX(idPres) AS idPres, prestado \r\n"
				+ "FROM prestamos\r\n"
				+ "WHERE idLibro=?\r\n"
				+ "GROUP BY idLibro,prestado\r\n"
				+ "ORDER BY idPres DESC\r\n"
				+ "LIMIT 1";
		
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, codigo);
			
			ResultSet resul=ps.executeQuery();
			while(resul.next()) {
				idLibro=resul.getInt(1);
			}
			
			PreparedStatement ps1=conn.prepareStatement(sql1);
			ps1.setInt(1, idLibro);
			
			ResultSet result=ps1.executeQuery();
			
			while(result.next()) {
				prestado=result.getBoolean(3);
			}
			if(prestado) {
				return true;
			}
			else {
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Error","Mensaje informativo",JOptionPane.ERROR_MESSAGE);
			closeConnection();
			return false;
		}
		
		
	}
	public ArrayList<Object> verHistorico() {
		ArrayList<Object> historico=new ArrayList<Object>();
		
		String historicosql="SELECT pre.fecha, pre.fechaDev, li.codigo, so.nombre "
				+ "FROM prestamos AS pre "
				+ "JOIN libro AS li ON pre.idLibro = li.idLibro "
				+ "JOIN socio AS so ON so.idCliente = pre.idCliente";
		try {
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery(historicosql);
			
			while(rs.next()) {
				historico.add(new Object[] {rs.getString(3),rs.getString(4),rs.getDate(1),rs.getDate(2)});
			}
			return historico;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			closeConnection();
			JOptionPane.showMessageDialog(null, "Error adquiriendo el historiaL","Mensaje informativo",JOptionPane.ERROR_MESSAGE);
			return historico;
		}
		
		
	}
	public Boolean Alquilar(String[] values) {
		Boolean existe=false;
		Boolean disponible=false;
		int idLibro=0;
		int idCliente=0;
		String code=values[0];
		String dni=values[1];

		if(values[0].equals("")||values[1].equals("")) {
			JOptionPane.showMessageDialog(null, "Debes completar los datos indicados","Mensaje informativo",JOptionPane.INFORMATION_MESSAGE);
			return false;
		}else {
			ArrayList<Cliente> listaclientes=verSocios();
			for (Cliente cliente : listaclientes) {
				if(cliente.getDNI().equals(dni)) {
					existe=true;
					idCliente=cliente.getIdCliente();
				}
			}
			ArrayList<Libro> librosDisponibles=verLibrosDisponibles();
		
			for (Libro libro : librosDisponibles) {
				
				if(libro.getCode().equals(code)) {
					disponible=true;
					idLibro=libro.getIdLibro();
				}
			}
			if(existe && disponible) {
				String alquilar="INSERT INTO prestamos (idLibro,idCliente,fecha,fechaDev,prestado) VALUES (?,?,?,?,?)";
				LocalDate fecha=LocalDate.now();
				Date fechasql=Date.valueOf(fecha);
				
				try {
					PreparedStatement ps=conn.prepareStatement(alquilar);
					ps.setInt(1, idLibro);
					ps.setInt(2, idCliente);
					ps.setDate(3, fechasql);
					ps.setDate(4, null);
					ps.setInt(5, 1);
					
					int filas=ps.executeUpdate();
					if(filas>0) {
						JOptionPane.showMessageDialog(null, "Se ha completado correctamente","Mensaje informativo",JOptionPane.INFORMATION_MESSAGE);
					}
					ps.close();
					return true;
		
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					JOptionPane.showMessageDialog(null, "Error alquilando","Mensaje informativo",JOptionPane.ERROR_MESSAGE);
					closeConnection();
					return false;
				}
			}else {
				if(!existe) {
					JOptionPane.showMessageDialog(null, "No se puede realizar porque no eres socio,date de alta","Mensaje informativo",JOptionPane.INFORMATION_MESSAGE);
				}
				else {
					JOptionPane.showMessageDialog(null, "No se puede realizar porque ya está prestado","Mensaje informativo",JOptionPane.INFORMATION_MESSAGE);
				}
				return false;
			
			}
		}		
		
	}
	public void Devolver(String value) {
		ArrayList<Object> listaLibros=verLibrosAlquilados();
		Boolean devolver=false;
		LocalDate fecha=LocalDate.now();
		Date fechaSql = Date.valueOf(fecha);
		int idLibro=0;
		int idPres=0;
		
		if(value.equals("")) {
			JOptionPane.showMessageDialog(null, "Debes introducir el código","Mensaje informativo",JOptionPane.INFORMATION_MESSAGE);
		}else {
			for (Object object : listaLibros) {
				if(object instanceof Object[]) {
					Object[] array=(Object[]) object;	
					if(array[1].equals(value)) {
						devolver=true;
					}				
				}
			}
			if(devolver) {
				String sql="SELECT idLibro from libro where codigo= ?";
				String sql1="SELECT idPres from prestamos where idLibro=? and prestado=1";
				String update="UPDATE prestamos set prestado=0 ,fechaDev=? where idPres= ?";
				try {
					PreparedStatement ps=conn.prepareStatement(sql);
					ps.setString(1, value);
					ResultSet rs=ps.executeQuery();
					
					while(rs.next()) {
						idLibro=rs.getInt(1);
					}
					
					PreparedStatement ps2=conn.prepareStatement(sql1);
					ps2.setInt(1, idLibro);
					ResultSet rs1=ps2.executeQuery();
					
					while(rs1.next()) {
						idPres=rs1.getInt(1);
					}
					
					
					PreparedStatement ps1=conn.prepareStatement(update);
					ps1.setDate(1, fechaSql);
					ps1.setInt(2, idPres);
					int filas=ps1.executeUpdate();
					
					if(filas>0) {
						JOptionPane.showMessageDialog(null, "Se ha actualizaco correctamente","Mensaje informativo",JOptionPane.INFORMATION_MESSAGE);
					}
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					JOptionPane.showMessageDialog(null, "Error devolviendo el libro","Mensaje informativo",JOptionPane.ERROR_MESSAGE);
					closeConnection();
				}
			}		
		}		
	}
	public void añadirSocio(String[] values) {
		String nombre=values[0];
		String apellido=values[1];
		String dni=values[2];
		
		ArrayList<Cliente> clientes=verSocios();
		Boolean existe=false;
		
		if(nombre.equals("")||apellido.equals("")||dni.equals("")) {
			JOptionPane.showMessageDialog(null, "Debes introducir todos los campos","Mensaje informativo",JOptionPane.INFORMATION_MESSAGE);
		}else {
			for (Cliente cliente : clientes) {
				if(dni.equals(cliente.getDNI())) {
					existe=true;
					break;
				}
			}
			if(!existe) {
				if(!validarEstructuraDNI(dni)) {
					JOptionPane.showMessageDialog(null,"El formato del DNI es incorrecto","Mensaje informativo" ,JOptionPane.INFORMATION_MESSAGE);
					
				}else {
					if(nombre.equals("")) {
						JOptionPane.showMessageDialog(null,"Debes introducir un nombre","Mensaje informativo" ,JOptionPane.INFORMATION_MESSAGE);
					}
					if(apellido.equals("")) {
						JOptionPane.showMessageDialog(null,"Debes introducir un apellido","Mensaje informativo" ,JOptionPane.INFORMATION_MESSAGE);
					}
					
					String añadirSocio="INSERT INTO socio (DNI,nombre,apellido) VALUES (?,?,?)";
					
					try {
						PreparedStatement ps=conn.prepareStatement(añadirSocio);
						ps.setString(1, dni);
						ps.setString(2, nombre);
						ps.setString(3, apellido);
						
						int filas=ps.executeUpdate();
						if(filas>0) {
							JOptionPane.showMessageDialog(null,"Se ha añadido el usuario correctamente","Mensaje informativo" ,JOptionPane.INFORMATION_MESSAGE);
						}else {
							JOptionPane.showMessageDialog(null,"ERROR: introduciendo usuario","Mensaje informativo" ,JOptionPane.ERROR_MESSAGE);
						}
						ps.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					
						closeConnection();
					}
				}
					
			}else {
				JOptionPane.showMessageDialog(null,"ERROR: el usuario ya existe","Mensaje informativo" ,JOptionPane.ERROR_MESSAGE);
			}
		}				
	}
	public void eliminarSocio(String dni) {
		ArrayList<Cliente> clientes=verSocios();
		Boolean existe=false;
		if(dni.equals("")) {
			JOptionPane.showMessageDialog(null, "Debes introducir el DNI","Mensaje informativo",JOptionPane.INFORMATION_MESSAGE);
		}else {
			if(validarEstructuraDNI(dni)) {
				for (Cliente cliente : clientes) {
					if(dni.equals(cliente.getDNI())) {
						existe=true;
						break;
					}
				}
				if(existe) {
					String eliminarSocio="DELETE from socio where DNI=?";
					
					PreparedStatement ps;
					try {
						ps = conn.prepareStatement(eliminarSocio);
						ps.setString(1, dni);
						
						int filas=ps.executeUpdate();
						if(filas>0) {
							JOptionPane.showMessageDialog(null, "Se ha borrado correctamente","Mensaje informativo",JOptionPane.INFORMATION_MESSAGE);
						}else {
							JOptionPane.showMessageDialog(null, "NO se ha borrado correctamente","Mensaje informativo",JOptionPane.ERROR_MESSAGE);
						}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}else {
					JOptionPane.showMessageDialog(null, "No exite el usuario mencionado","Mensaje informativo",JOptionPane.INFORMATION_MESSAGE);
				}
			}else {
				JOptionPane.showMessageDialog(null,"El formato del DNI es incorrecto","Mensaje informativo" ,JOptionPane.INFORMATION_MESSAGE);
			}
		}
		
		
		
	}
	 private static boolean validarEstructuraDNI(String dni) {
	        // Comprobar longitud
	        if (dni.length() != 9) {
	            return false;
	        }

	        // Verificar que los primeros 8 caracteres sean numéricos
	        String numeroStr = dni.substring(0, 8);
	        if (!esNumero(numeroStr)) {
	            return false;
	        }

	        // Verificar que el último carácter sea una letra
	        char letra = dni.charAt(8);
	        return Character.isLetter(letra);
	    }

	    private static boolean esNumero(String str) {
	        try {
	            Integer.parseInt(str);
	            return true;
	        } catch (NumberFormatException e) {
	            return false;
	        }
	    }

}
