package dataBase;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import vista.VentanaAlquilarLibro;
import vista.VentanaCrearUsuario;
import vista.VentanaDevolverLibro;
import vista.VentanaEliminarSocio;
import vista.VentanaLibrosAlquilados;
import vista.VentanaLibrosDisponibles;
import vista.VentanaVerHistorico;
import vista.VentanaVerSocios;

public class Controlador implements ActionListener {
	private Modelo modelo;
	private VentanaAlquilarLibro  ventanaAlquilarLibro=new VentanaAlquilarLibro(this);
	private VentanaDevolverLibro ventanaDevolverLibro=new VentanaDevolverLibro(this);
	private VentanaCrearUsuario ventanaCrearUsuario=new VentanaCrearUsuario(this);
	private VentanaEliminarSocio ventanaEliminarSocio=new VentanaEliminarSocio(this);
		
	Controlador(Modelo modelo){
		this.modelo=modelo;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		String comando=e.getActionCommand();	
		
		if(comando.equals("Alquilar")) {
			
			ventanaAlquilarLibro.setVisible(true);
		}
		if(comando.equals("Devolver")) {
			
			ventanaDevolverLibro.setVisible(true);
		}
		if(comando.equals("Ver libros disponibles")) {
			VentanaLibrosDisponibles ventanaLibrosDisponibles=new VentanaLibrosDisponibles(this);
			ventanaLibrosDisponibles.setVisible(true);
			
			ventanaLibrosDisponibles.ActualizarTbla(modelo.verLibrosDisponibles());
		}
		if(comando.equals("Ver socios")) {
			VentanaVerSocios ventanaVerSocios=new VentanaVerSocios(this);
			ventanaVerSocios.setVisible(true);
			
			ventanaVerSocios.actualizarTabla(modelo.verSocios());
			
		}
		if(comando.equals("Libros alquilados")) {
			VentanaLibrosAlquilados ventanaLibrosAlquilados=new VentanaLibrosAlquilados(this);
			ventanaLibrosAlquilados.setVisible(true);
			
			ventanaLibrosAlquilados.ActualizarTabla(modelo.verLibrosAlquilados());
		}
		if(comando.equals("Historico")) {
			VentanaVerHistorico ventanaVerHistorico=new VentanaVerHistorico(this);
			ventanaVerHistorico.setVisible(true);
			
			ventanaVerHistorico.ActualizarTabla(modelo.verHistorico());
		}
		if(comando.equals("AlquilarLibro")) {
			modelo.Alquilar(ventanaAlquilarLibro.getValues());
			
		}
		if(comando.equals("CancelarLibro")) {
			ventanaAlquilarLibro.dispose();
		}
		if(comando.equals("DevolverLibro")) {
			modelo.Devolver(ventanaDevolverLibro.getValue());
		}
		if(comando.equals("CancelarDevolverLibro")) {
			ventanaDevolverLibro.dispose();
		}
		if(comando.equals("Crear Usuario")) {
			ventanaCrearUsuario.setVisible(true);
		}
		if(comando.equals("Nuevo Usuario")) {
			modelo.añadirSocio(ventanaCrearUsuario.getValues());
		}
		if(comando.equals("Cancelar crear")) {
			ventanaCrearUsuario.dispose();
		}
		if(comando.equals("Eliminar Usuario")) {
			ventanaEliminarSocio.setVisible(true);
		}
		if(comando.equals("Confirmar ELIMINAR")) {
			modelo.eliminarSocio(ventanaEliminarSocio.getValue());
		}
		if(comando.equals("Cancelar ELIMINAR")) {
			ventanaEliminarSocio.dispose();
		}
	}

}
