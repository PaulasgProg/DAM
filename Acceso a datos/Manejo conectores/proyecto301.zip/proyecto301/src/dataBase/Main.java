package dataBase;

import vista.VentanaPrincipal;

public class Main {

	public static void main(String[] args) {
		
		Modelo modelo=new Modelo();
		Controlador controlador=new Controlador(modelo);
		VentanaPrincipal ventanaPrincipal=new VentanaPrincipal(controlador);
		ventanaPrincipal.setVisible(true);

	}

}
