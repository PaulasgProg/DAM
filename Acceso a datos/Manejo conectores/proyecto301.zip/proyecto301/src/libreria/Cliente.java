package libreria;

public class Cliente {
	private int idCliente;
	private String DNI;
	private String name;
	private String surname;
	
	public Cliente() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Cliente(int idCliente, String dNI, String name, String surname) {
		super();
		this.idCliente = idCliente;
		DNI = dNI;
		this.name = name;
		this.surname = surname;
	}
	public Cliente(String dNI, String name, String surname) {
		super();
		DNI = dNI;
		this.name = name;
		this.surname = surname;
	}

	public int getIdCliente() {
		return idCliente;
	}

	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}

	public String getDNI() {
		return DNI;
	}

	public void setDNI(String dNI) {
		DNI = dNI;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	@Override
	public String toString() {
		return "Cliente [idCliente=" + idCliente + ", DNI=" + DNI + ", name=" + name + ", surname=" + surname + "]";
	}
	
	
	
	
	
	
}