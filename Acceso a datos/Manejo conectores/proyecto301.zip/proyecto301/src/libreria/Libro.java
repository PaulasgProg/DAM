package libreria;

public class Libro {
	private int idLibro;
	private String code;
	private String title;
	private String autor;
	

	public Libro() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Libro(int idLibro, String code, String title, String autor) {
		super();
		this.idLibro = idLibro;
		this.code = code;
		this.title = title;
		this.autor = autor;
	}
	public Libro( String code, String title, String autor) {
		super();
		this.code = code;
		this.title = title;
		this.autor = autor;
	}
	public int getIdLibro() {
		return idLibro;
	}
	public void setIdLibro(int idLibro) {
		this.idLibro = idLibro;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	@Override
	public String toString() {
		return "Libro [idLibro=" + idLibro + ", code=" + code + ", title=" + title + ", autor=" + autor + "]";
	}
}
